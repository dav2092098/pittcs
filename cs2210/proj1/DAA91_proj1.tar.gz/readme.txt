CS2210 Proj 1

Lexical analyzer

To execute, proceed as follows:
1) Compile with the command:
$ 	make

2) Read input with the command (example):
$	./lexer < proj1_tests/hello.mjava 	

